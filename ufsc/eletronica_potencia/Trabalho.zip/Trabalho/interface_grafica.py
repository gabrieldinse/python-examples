# Author: gabri
# File: interface_grafica
# Date: 17/11/2019
# Made with PyCharm

# Standard Library
import sys

# Third party modules
from PyQt5.QtWidgets import QMainWindow, QApplication

# Local application imports
from main_window import Ui_MainWindow
from serial_device import SerialDevice


class VoltageController(SerialDevice):
    def send_voltage(self, value):
        """ Envia o comando de ligar. """
        if self.isWritable():
            print(f"Tensão: {value}")
            self.write(bytes(f"{value:.3}", "utf-8"))


class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.voltage = 0.0
        self.min_voltage = 0.0
        self.max_voltage = 24.0
        self.voltage_controller = VoltageController(debug=True)
        self.ui.output_voltage_slider.sliderMoved.connect(
            self.output_voltage_slider_moved)
        self.ui.output_voltage_slider.sliderReleased.connect(
            self.output_voltage_slider_released)

    def output_voltage_slider_released(self):
        self.voltage = float(self.ui.output_voltage_slider.value())
        self.voltage = self.voltage * (
                self.max_voltage - self.min_voltage) / 200.0 + self.min_voltage
        self.ui.output_voltage_label.setText(str(self.voltage) + " V")
        self.voltage_controller.send_voltage(self.voltage)

    def output_voltage_slider_moved(self):
        self.voltage = float(self.ui.output_voltage_slider.value())
        self.voltage = self.voltage * (
                self.max_voltage - self.min_voltage) / 200.0 + self.min_voltage
        self.ui.output_voltage_label.setText(str(self.voltage) + " V")

def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
